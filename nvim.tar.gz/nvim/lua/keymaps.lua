-- Editor
vim.g.mapleader = " "
vim.g.maplocalleader = " "

vim.opt.number = true
vim.opt.shiftwidth = 2

vim.api.nvim_set_keymap("n", "<C-h>", "<C-w>h", {})
vim.api.nvim_set_keymap("n", "<C-j>", "<C-w>j", {})
vim.api.nvim_set_keymap("n", "<C-i>", "<C-w>i", {})
vim.api.nvim_set_keymap("n", "<C-l>", "<C-w>l", {})

vim.api.nvim_set_keymap("n", "<S-h>", ":bprevious<CR>", {noremap = true})
vim.api.nvim_set_keymap("n", "<S-l>", ":bnext<CR>", {noremap = true})
