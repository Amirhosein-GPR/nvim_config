local wk = require("which-key")

wk.register({
  q = { "<cmd>q<cr>", "Quit window" },
  m = { "<cmd>w<cr>", "Save file" },
  b = {
    name = "Buffer",
    q = { "<cmd>bdelete<cr>", "Quit buffer" },
    w = { "<cmd>%bd|e#<cr>", "Quit other buffers" }
  },
  e = { "<cmd>NvimTreeToggle<cr>", "Toggle NvimTree" },
  f = {
    name = "File",
    f = { "<cmd>Telescope find_files<cr>", "Find files" },
    g = { "<cmd>Telescope live_grep<cr>", "Live grep" },
    b = { "<cmd>Telescope buffers<cr>", "Buffers" },
    h = { "<cmd>Telescope help_tags<cr>", "Help tags" }
  }
}, { prefix = "<leader>" })
