require('lualine').setup {
  options = { theme  = "one_monokai" }
}
