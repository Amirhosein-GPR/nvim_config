require("fidget").setup {}
