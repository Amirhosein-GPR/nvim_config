require("rust-tools").setup()
